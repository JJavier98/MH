data: almacena archivos de datos
doc: aquí se encuentra la memoria
src: contiene el script de python.

Para ejecutar la práctica con semilla=1 tan solo escribir `make`
Si se quiere especificar la semilla a usar -> editar el archivo Makefile de la siguiente forma:
            python3.6 src/Practica1.py 'semilla'

o ejecutar manualmente desde la terminal.
